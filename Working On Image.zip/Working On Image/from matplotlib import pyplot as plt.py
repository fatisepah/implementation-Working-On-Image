#showing the image with matplotlib
from matplotlib import pyplot as plt
from matplotlib import image as mpimg
 
plt.title("Cat Image")
plt.xlabel("X pixel scaling")
plt.ylabel("Y pixels scaling")

#open the image--- we can enter the address in our pc or uplaod image in colab 
image = mpimg.imread("C:\\Users\\ASUS\\Desktop\\ss\\Cat\\OIP (5).jpeg")

#showing the image(color image)
plt.imshow(image)
plt.show()