#convert image 3d to 2d
from PIL import Image
from sys import displayhook
from numpy import array

#open the image--- we can enter the address in our pc or uplaod image in colab
img = Image.open('C:\\Users\\ASUS\\Desktop\\ss\\Cat\\OIP (5).jpeg')

#showing the image(color image)
img.show()

#converting to 2d with this line
img = img.convert('L')
img.save('greyscale.png')

#showing the image(grayscale image)
img.show()

#converting image to matrix and print it
ar = array(img)
print(ar)
print(ar.shape)