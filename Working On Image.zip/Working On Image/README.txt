Writing some Python files to work on the photo:
This photo should be on the desktop or on the server or in Google's folder
Convert matrix to photo and photo to matrix
Convert photo to grayscale

نوشتن چند فایل پایتون برای کار بر روی عکس:
این عکس روی دسکتاپ باشد و یا روی سرور و یا در کولب گوگل
تبدیل ماتریس به عکس و عکس به ماتریس
تبدیل عکس به 
grayscale
