#convert image to matrix and then convert same image to matrix
from sys import displayhook
from PIL import Image
from numpy import array

#open the image--- we can enter the address in our pc or uplaod image in colab
im_1 = Image.open(r"C:\Users\ASUS\Desktop\ss\Cat\OIP (5).jpeg")

#showing the image(color image)
im_1.show()

#converting image to matrix and print it
ar = array(im_1)
print(ar)

#converting matrix to image and show it
data = Image.fromarray(ar)
data.show()

print(ar.shape)


